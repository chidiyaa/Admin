package com.example.AdminService.exception;
public class RecruitmentException extends Exception {

	String msg;
	public RecruitmentException(String msg) {
        super(msg);
    }

	public RecruitmentException() {
		// TODO Auto-generated constructor stub
	}
}