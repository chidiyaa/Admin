package com.example.AdminService.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.AdminService.entities.CompanyMaster;

public interface CompanyMasterDAO extends JpaRepository<CompanyMaster,String>{

}
